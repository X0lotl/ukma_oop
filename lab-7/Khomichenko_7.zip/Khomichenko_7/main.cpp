#include "Screen.h"

int main() {
  Screen screen;
  screen.processInput();
  return 0;
}